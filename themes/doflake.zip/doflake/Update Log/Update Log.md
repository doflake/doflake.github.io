$Day~2021/08/14$

***

> 完成  $post-index.ejs$​（效果见下）​
>
> $Made ~ By ~ : ~ Dove$​
>
> > $Headimg$​ 大小适配虽然有了, 但是不够完善, 不太好
> >

![20210814-1](Photo\20210814-1.png)



$Day~2021/08/16$

***

> 完成 $aside.ejs$ 中 $author$ 组件
>
> $Made~By~:~Dove$​
>
> > 基本完工
> >
> > 预计在下方加入 **站点信息**

![20180816-1](Photo\20210816-1.png)

> $post-index.ejs$ 增添 显示 $Tag$ 功能
>
> $Made~By~:~Dove$​
>
> > 基本完工

![20180816-2](Photo\20210816-2.png)
